# Cricket Scoreboard Web Application

A real-time cricket match scoring system that allows users to update the score by clicking buttons for various cricket events.

## Features

- Real-time score tracking for a cricket match
- Individual player scores for Rahul and Rohit
- Support for all standard cricket scoring events:
  - Runs (1, 2, 3, 4, 6)
  - Wickets (Wicket, LBW)
  - Extras (Wide, No Ball, Bye, Leg Bye)
  - Free Hit
- Automatic striker switching for odd runs
- Over tracking with automatic striker switch at over completion
- Reset functionality to start a new match

## How to Run

1. Simply open the `index.html` file in any modern web browser.
2. No server or additional dependencies are required.

## Assumptions

1. The application simulates a match with only two batsmen (Rahul and Rohit).
2. After a wicket falls, the next batsman is always Rahul (for simulation purposes).
3. The maximum wickets are limited to 10 (standard cricket rules).
4. Free hit lasts for only one delivery (the next ball after being called).
5. No balls and wides don't count as valid deliveries for over progression.

## Technologies Used

- HTML5
- CSS3
- JavaScript (Vanilla JS, no frameworks)