// Game state variables
let teamRuns = 0;
let teamWickets = 0;
let overs = 0; // full overs
let balls = 0; // balls in current over (0-5)
let isFreeHit = false;

// Player states
let players = {
    rahul: {
        runs: 0,
        isOut: false,
        isStriker: true
    },
    rohit: {
        runs: 0,
        isOut: false,
        isStriker: false
    }
};

// DOM elements
const teamRunsElement = document.getElementById('team-runs');
const teamWicketsElement = document.getElementById('team-wickets');
const oversElement = document.getElementById('overs');
const freeHitIndicator = document.getElementById('free-hit-indicator');
const rahulRunsElement = document.getElementById('rahul-runs');
const rohitRunsElement = document.getElementById('rohit-runs');
const rahulStarElement = document.getElementById('rahul-star');
const rohitStarElement = document.getElementById('rohit-star');
const rahulElement = document.getElementById('rahul');
const rohitElement = document.getElementById('rohit');

// Initialize the scoreboard
function updateScoreboard() {
    teamRunsElement.textContent = teamRuns;
    teamWicketsElement.textContent = teamWickets;
    oversElement.textContent = `${overs}.${balls}`;
    
    rahulRunsElement.textContent = players.rahul.runs;
    rohitRunsElement.textContent = players.rohit.runs;
    
    // Update striker indicators
    if (players.rahul.isStriker) {
        rahulStarElement.textContent = '*';
        rohitStarElement.textContent = '';
        rahulElement.classList.add('active');
        rohitElement.classList.remove('active');
    } else {
        rahulStarElement.textContent = '';
        rohitStarElement.textContent = '*';
        rahulElement.classList.remove('active');
        rohitElement.classList.add('active');
    }
    
}

// Add runs to the score
function addRuns(runs) {
    if (teamWickets >= 10) return; // Can't score if all out
    
    // Add runs to team and striker
    teamRuns += runs;
    const striker = players.rahul.isStriker ? players.rahul : players.rohit;
    striker.runs += runs;
    
    // Switch striker for odd runs (1 or 3)
    if (runs === 1 || runs === 3) {
        switchStriker();
    }
    
    // Increment ball count for valid deliveries
    incrementBallCount();
    
    updateScoreboard();
}

// Add extras that don't count against the bowler or batsman
function addWide() {
    if (teamWickets >= 10) return;
    
    teamRuns += 1;
    // No ball increment for wides
    updateScoreboard();
}

function addNoBall() {
    if (teamWickets >= 10) return;
    
    teamRuns += 1;
    // Add run to striker's score as well
    const striker = players.rahul.isStriker ? players.rahul : players.rohit;
    striker.runs += 1;
    // No ball increment for no balls
    updateScoreboard();
}

function addBye() {
    if (teamWickets >= 10) return;
    
    teamRuns += 1;
    incrementBallCount();
    updateScoreboard();
}

function addLegBye() {
    if (teamWickets >= 10) return;
    
    teamRuns += 1;
    incrementBallCount();
    updateScoreboard();
}

// Wicket functions
function addWicket() {
    if (teamWickets >= 10 || isFreeHit) return;
    
    teamWickets = Math.min(10, teamWickets + 1);
    const striker = players.rahul.isStriker ? players.rahul : players.rohit;
    const nonStriker = players.rahul.isStriker ? players.rohit : players.rahul;

    striker.isOut = true;
    striker.isStriker = false;
    
     if (!nonStriker.isOut) {
        nonStriker.isStriker = true;
    }
    incrementBallCount();
    updateScoreboard();
}

function addLBW() {
    // Same logic as wicket
    addWicket();
}

function addFreeHit() {

    if (teamWickets >= 10) return;
    teamRuns += 1;
    isFreeHit = true;
    
    updateScoreboard();
}

// Switch striker manually
function switchStriker() {
    players.rahul.isStriker = !players.rahul.isStriker;
    players.rohit.isStriker = !players.rohit.isStriker;
    updateScoreboard();
}


// Reset the scoreboard
function resetScoreboard() {
    teamRuns = 0;
    teamWickets = 0;
    overs = 0;
    balls = 0;
    isFreeHit = false;
    
    players = {
        rahul: {
            runs: 0,
            isOut: false,
            isStriker: true
        },
        rohit: {
            runs: 0,
            isOut: false,
            isStriker: false
        }
    };
    
    updateScoreboard();
}

// Helper function to increment ball count and handle over changes
function incrementBallCount() {
    if (isFreeHit) {
        isFreeHit = false;
        updateScoreboard();
        return;
    }

    balls += 1;
    if (balls >= 6) {
        balls = 0;
        overs += 1;
        // Switch strike at end of over
        switchStriker();
    }
    updateScoreboard();
}

// Initialize the scoreboard on page load
window.onload = function() {
    document.getElementById('free-hit-indicator').classList.add('hidden');
    updateScoreboard();
};